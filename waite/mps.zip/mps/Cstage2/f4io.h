#ifndef F4IO_H
#define F4IO_H

extern int maxch,jchan[24];

extern int ioop(int jop, int jch, int jba[], int jp1, int *jp2);

#endif
